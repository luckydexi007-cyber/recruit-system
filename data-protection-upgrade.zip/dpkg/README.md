# 版本迭代不清空用户数据 — 配置说明

## 一、为什么现在迭代会清空用户
Render 免费版容器是"临时"的。当前线上存储方式是 file（容器内 data.json），
每当你更新代码/重新部署 → 容器被重建 → data.json 归零 → 用户、简历全部消失。

医院结论证据：线上 /api/health 返回 {"storage":"file"}。

## 二、两层防护（必须都做）

### 第 1 层：外部数据库（根本解决）
把数据存到容器外的 Postgres，容器怎么重建都不丢。
1) 去 https://neon.tech 免费注册，建一个数据库，复制连接串（形如
   postgresql://user:pass@xxx.neon.tech/neondb?sslmode=require）。
2) Render → 你的服务 recruit-system → Environment → Add Environment Variable：
   名称 DATABASE_URL  值 = 刚复制的连接串
3) 保存后自动重新部署。

### 第 2 层：代码护栏（本包 server.js）
即使以后误操作，也不会用空数据覆盖已有数据：
- 存储未成功加载（dbLoaded=false）时，绝不写盘；
- "空库"永不覆盖"非空库"（0 条不会覆盖 N 条）；
- 本地文件采用原子写 + 自动备份 .bak；
- 只允许两条合法删除通道：用户本人注销 / 终端管理员删用户。

## 三、必须替换的两个文件（否则第 1 层无效）
把本包里的这两个文件，上传覆盖到 GitHub 仓库根目录的同名文件：
- server.js      （含 Postgres + 数据保护层）
- package.json   （新增 "pg" 依赖；旧版没有它，配了 DATABASE_URL 也连不上数据库）

## 四、Render 关键设置（极易踩坑）
Build Command 不能是 `echo "no build needed"`，否则不会执行 npm install，
pg 依赖不会被安装。请把 Build Command 改为：
    npm install
Start Command 保持：node server.js

## 五、验证是否生效
部署完成后访问： https://recruit-system.onrender.com/api/health
- 看到 "storage":"postgres"  → 成功，之后更新代码数据都在。
- 仍是 "storage":"file"      → DATABASE_URL 或 pg 依赖还没生效，检查第四步。

## 六、日常迭代的正确做法
以后更新网页（比如改 index.html 界面）只动 index.html 即可，
server.js / package.json / DATABASE_URL 三者保持不变，数据就不会被清空。
