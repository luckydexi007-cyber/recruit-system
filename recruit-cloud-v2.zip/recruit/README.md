# 车辆与交通学院·团总支学生会 招新系统（云端持久化版 v2）

## 本次修复与新增
1. **部门选项卡片嵌套错乱修复**：复选框行不再层层套娃，六个部门卡片排列整齐。
2. **数据持久化（升级重点）**：改用 Postgres 存储，重新部署/迭代不会再清空用户数据。
   - 未配置 `DATABASE_URL` 时自动回退本地 `data.json`（仅本地开发用，部署会丢）。
3. **注销账户**：用户中心新增「🗑️ 注销账户」按钮，用户可永久删除自己的账号、简历与全部投递记录。
4. 意向部门按点选先后显示「第一/第二/第三志愿」（最多 3 个）。

## 部署步骤（Render）
### 第 1 步：创建免费 Postgres 数据库（推荐 Neon，永久免费）
1. 打开 https://neon.tech 注册 → New Project → 复制连接串（形如
   `postgresql://user:pass@xxx.neon.tech/neondb?sslmode=require`）。

### 第 2 步：更新 GitHub 仓库文件
把本目录下这些文件上传覆盖到仓库（Add file → Upload files）：
- `server.js`（新版）
- `index.html`（在 `public/` 里；若你的仓库是扁平结构，就传到仓库根目录）
- `package.json`（新增 pg 依赖）
- `render.yaml`、`Procfile`

### 第 3 步：在 Render 配置环境变量
Dashboard → 你的服务 → Environment → Add Environment Variable：
- `TERMINAL_USER` = admin
- `TERMINAL_PASS` = 123a123
- `DATABASE_URL` = 第 1 步复制的连接串   ← 关键，加上后数据不再丢失

保存后 Render 会自动重新部署。

## 存储说明
- 配置了 `DATABASE_URL`：数据保存在 Postgres，跨设备、跨网络、重新部署都不丢。
- 未配置：使用本地文件，重新部署会重置（仅用于本地测试）。
